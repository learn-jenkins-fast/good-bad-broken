package com.example.course.entity;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the LOCATION database table.
 * 
 */
public class Location implements Serializable {
	private static final long serialVersionUID = 1L;


	private String city;

	private String state;

	private String street;

	private List<ScheduledClass> scheduledClasses;



	public Location() {
	}


	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public List<ScheduledClass> getScheduledClasses() {
		return this.scheduledClasses;
	}

	public void setScheduledClasses(List<ScheduledClass> scheduledClasses) {
		this.scheduledClasses = scheduledClasses;
	}
	public void addScheduleClass(ScheduledClass scheduledClass) {
		this.scheduledClasses.add(scheduledClass);
	}

}