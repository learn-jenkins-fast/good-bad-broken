package com.example.course.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


public class ScheduledClass implements Serializable {
	private static final long serialVersionUID = 1L;
	private static int nextId = 1;
	private Integer id; 
	private Timestamp start;

	private List<Location> locations;

	private Course course;

	public ScheduledClass() {
		id = getNextId();
	}

	private static  synchronized Integer getNextId() { return new Integer(nextId++);}
	public Timestamp getStart() {
		return this.start;
	}

	public void setStart(Timestamp start) {
		this.start = start;
	}

	public List<Location> getLocations() {
		return this.locations;
	}

	public void setLocations(List<Location> locations) {
		this.locations = locations;
	}



	public Course getCourse() {
		return this.course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

}