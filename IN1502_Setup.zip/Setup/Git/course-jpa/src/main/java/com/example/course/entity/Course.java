package com.example.course.entity;

import java.io.Serializable;
import java.util.List;


public class Course implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	@Override
	public String toString() {
		return "Course [id=" + id + ", code=" + code + ", description=" + description + ", duration=" + duration
				+ ", fee=" + fee + ", scheduledClasses=" + scheduledClasses + "]";
	}

	private String code;

	private String description;

	private int duration;

	private int fee;

	private List<ScheduledClass> scheduledClasses;

	public Course() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getDuration() {
		return this.duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getFee() {
		return this.fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

	public List<ScheduledClass> getScheduledClasses() {
		return this.scheduledClasses;
	}

	public void setScheduledClasses(List<ScheduledClass> scheduledClasses) {
		this.scheduledClasses = scheduledClasses;
	}

	public ScheduledClass addScheduledClass(ScheduledClass scheduledClass) {
		getScheduledClasses().add(scheduledClass);
		scheduledClass.setCourse(this);

		return scheduledClass;
	}

	public ScheduledClass removeScheduledClass(ScheduledClass scheduledClass) {
		getScheduledClasses().remove(scheduledClass);
		scheduledClass.setCourse(null);

		return scheduledClass;
	}

}